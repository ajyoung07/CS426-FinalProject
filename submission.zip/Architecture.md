# System purpose:
The purpose of this system is to provide a scalable system for people to host multiplayer games to be played online with (or without) friends. The use of Docker allows the system to be easily extendible and accessible. The use of NGINX for an API gateway and load balancing allows for the system to easily scale horizontally, supporting lots of different users at once.

# Service boundaries
I have a user service whose main goal is to keep track of user information such as friends, favorite games, and login information. I have a chat service whose main goal is to handle user-to-user communication. Lastly, I have a game service whose goal is to handle game logic and store information about individual matches, such as who was playing and the moves made by each player.
