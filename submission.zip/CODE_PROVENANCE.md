# AI Tools Used
For this milestone, I used Copilot to help me debug a big issue I had with my Dev Container. This did not correspond to any code done for this milestone. All code is essentially copied from course material and past homeworks.

# Code sources
Lecture material from the Advanced API design patterns lecture, Orchestration lecture, API gateway lecture, and Database-Per-Service lecture.

# Libraries and Frameworks
I utilized FastAPI, Redis, NGINX, and Pydantic for this milestone as these are the ones we've used a lot in the course and what I am most familiar with at this point.

# Collobartion
No collabartion.
