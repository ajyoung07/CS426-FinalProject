# IDEA

Turn-based multiplayer game

# Services:

- User service
- Game service
- Chat service
